// Dummy file for compiling homework 2

public class PriorityQueue implements IPriorityQueue {
    PriorityQueue(){}
    public IPriorityQueue addElt(int elt) {return this;}
    public IPriorityQueue remMinElt() {return this;}
    public int getMinElt() {return 0;}
    public boolean isEmpty() {return true; }
}