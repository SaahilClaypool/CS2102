import tester.Tester;

/**
 * Created by Saahil on 11/15/2015.
 */
public class Main {
    public static void main(String[] args)
    {
        Examples e = new Examples();
        Tester.run(e);


    }
}
